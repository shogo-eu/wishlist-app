# 画面仕様：お気に入り一覧ページ（Wishlist）

本ドキュメントでは、Wishlist App v1 における  
**お気に入り一覧ページ（Wishlist Page）の画面仕様**を定義する。

---

## 1. 対象画面
- Shopify のページ（例：`/pages/wishlist`）

---

## 2. 対象ユーザー
- ゲストユーザー
- ログインユーザー（Customer）

---

## 3. ページ構成（レイアウト）

### 3-1. 共通ブロック
- お気に入り商品一覧（variant単位）
- 空状態（Empty State）

---

## 4. お気に入り商品（variant）一覧

### 4-1. 表示単位
- 表示単位は **variant**
- 主キー：`variant_id`

### 4-2. アイテム操作（共通）
- お気に入り解除（削除）
- 商品詳細への遷移（`?variant=...` 付き）

---

## 6. 共有機能（商品：条件付き）
- 商品共有は `product.metafields.custom.share_enabled == true` の場合のみ表示
- 共有URLは商品詳細URL + `?variant=...`

---

## 7. 空状態（Empty State）

### 7-1. お気に入り商品が0件
- 「お気に入りはまだありません」
- 「気になる商品を♡で保存できます」

### 7-2. ログイン誘導（ゲスト）
- 「ログインするとコレクションもお気に入り登録できます」

---

## 8. 非対応（v1）
- ユーザー作成のフォルダ（コレクション作成/編集）
- お気に入り商品のフォルダ分類（item⇔folder紐づけ）
- コレクションの共有（必要ならv2で検討）

---

## 9. 関連ドキュメント
- `02_Requirements/functional_requirements.md`
- `04_Data_Design/wishlist_schema_customer.json`
- `04_Data_Design/wishlist_schema_guest.json`
- `04_Data_Design/metafield_definition.md`
- `03_UX_UI/screen_spec_pdp.md`
